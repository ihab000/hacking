<?php class Tokyo { 
#const caCert = 'user.pem';
#const userCsr = 'user.csr'; 
function sign($caCert, $userCsr) { 
	$caKey = file_get_contents('/root/Hacks/hacking/HTB/LaCasaDePapel/certs/ca.key');
	$userCert = openssl_csr_sign($userCsr, $caCert, $caKey, 365, ['digest_alg'=>'sha256']);
	openssl_x509_export($userCert, $userCertOut); print $userCertOut; } 
} 
#$caCert = file_get_contents('phpdomain.pem'); 
#$userCsr = file_get_contents('phpdomain.csr');
$caCert = "-----BEGIN CERTIFICATE-----
MIIDazCCAlOgAwIBAgIUB3PqtAujyqtgD+SXDUb+lhAOVnowDQYJKoZIhvcNAQEL
BQAwRTELMAkGA1UEBhMCQVUxEzARBgNVBAgMClNvbWUtU3RhdGUxITAfBgNVBAoM
GEludGVybmV0IFdpZGdpdHMgUHR5IEx0ZDAeFw0xOTA2MTYyMjQzMzlaFw0yMDA2
MTUyMjQzMzlaMEUxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEw
HwYDVQQKDBhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQwggEiMA0GCSqGSIb3DQEB
AQUAA4IBDwAwggEKAoIBAQDPczpU3s4Pmwdb7MJsi//m8mm5rEkXcDmratVAk2pT
WwWxudo/FFsWAC1zyFV4w2KLacIU7w8Yaz0/2m+jLx7wNH2SwFBjJeo5lnz+ux3H
B+NhWC/5rdRsk07h71J3dvwYv7hcjPNKLcRluXt2Ww6GXj4oHhwziE2ETkHgrxQp
7jB8pL96SDIJFNEQ1Wqp3eLNnPPbfbLLMW8MYQ4UlXOaGUdXKmqx9L2spRURI8dz
NoRCV3eS6lWu3+YGrC4p732yW5DM5Go7XEyps2BvnlkPrq9AFKQ3Y/AF6JE8FE1d
+daVrcaRpu6Sm73FH2j6Xu63Xc9d1D989+UsPCe7nAxnAgMBAAGjUzBRMB0GA1Ud
DgQWBBSiz1vMtAmQqcdkcquu4oBG3CLg2DAfBgNVHSMEGDAWgBSiz1vMtAmQqcdk
cquu4oBG3CLg2DAPBgNVHRMBAf8EBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQBP
UHGl53QqPVKwwmO5KfuDRwvYvLQtT+huojiOjEu+AR6/sBqd0AY3O/bzvsqXDHWT
uMep+VX4iG2JrJgGpYChrbyhfnmgf0jWvoAL8vGXRm7WjFg5fZ5s8wsX2JRTXf2j
+pBpZkk5flwNLANnKjfoAWN2WLeAPYl0SEflu6+dvaL0B8EPapxonuXQA4IPWMi3
Jis2/z6V5unPxXPtW9vNcIx4Qwea7IzYUoHOOtXBiWPHfppe8VPGMZDJOc0rtqFD
m6p34sxVM96/6mATNY/mnKAbn0HclQECFdgDWtn5ejX9TFXDSYrECXGe/yDGD5z6
RvwNsvGqtdj32+Ki9BTJ
-----END CERTIFICATE-----"; 
$userCsr = "-----BEGIN CERTIFICATE REQUEST-----
MIICijCCAXICAQAwRTELMAkGA1UEBhMCQVUxEzARBgNVBAgMClNvbWUtU3RhdGUx
ITAfBgNVBAoMGEludGVybmV0IFdpZGdpdHMgUHR5IEx0ZDCCASIwDQYJKoZIhvcN
AQEBBQADggEPADCCAQoCggEBAM9zOlTezg+bB1vswmyL/+byabmsSRdwOatq1UCT
alNbBbG52j8UWxYALXPIVXjDYotpwhTvDxhrPT/ab6MvHvA0fZLAUGMl6jmWfP67
HccH42FYL/mt1GyTTuHvUnd2/Bi/uFyM80otxGW5e3ZbDoZePigeHDOITYROQeCv
FCnuMHykv3pIMgkU0RDVaqnd4s2c89t9sssxbwxhDhSVc5oZR1cqarH0vaylFREj
x3M2hEJXd5LqVa7f5gasLinvfbJbkMzkajtcTKmzYG+eWQ+ur0AUpDdj8AXokTwU
TV351pWtxpGm7pKbvcUfaPpe7rddz13UP3z35Sw8J7ucDGcCAwEAAaAAMA0GCSqG
SIb3DQEBCwUAA4IBAQCLHHdifWRxOlcVsW3fRNAjN0gO9MPU5xw7YzRY1qsUO1Qr
0hZiF3KCrkgtr2iQ3rIEAPxz8eS3XX0MPvatMEYb5p77AieqAuxRIT4D8nnUPxiO
l4az2CkvB+uFFtyn9enAmRKHVtR0w+fxlLqoB44o451uGolDlDxOrw+oJueAW1VV
bzoNRps9o6vhl9IhSaN5m0UhMAUr6qwpKe4dAzAkHWPSgOTptNtdRACSShVfGWdJ
9SC3W27H7eVT/eSPb5bh5mYExHx4bAYNNRPuIj4ncqnENIzaM91PObEB2cfWLjD3
vTdbSMPSITId25j8gBY+QXIkA2Hd+njCFaLGoqLm
-----END CERTIFICATE REQUEST-----";
$f = new Tokyo(); 
$f->sign($caCert, $userCsr); 
?> 
