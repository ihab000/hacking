<?php
/* Write your PHP code here */
function sign() {
	$caKey = file_get_contents('/root/Hacks/hacking/HTB/LaCasaDePapel/ca.key');
	$caCert = file_get_contents('/root/Hacks/hacking/HTB/LaCasaDePapel/domain.crt');
	$userCsr = file_get_contents('/root/Hacks/hacking/HTB/LaCasaDePapel/domain.csr');
	$userCert = openssl_csr_sign($userCsr, $caCert, $caKey, 365, ['digest_alg'=>'sha256']);
    	openssl_x509_exporp($userCert, $userCertOut);
	return $userCertOut;
}
$nn = sign();
echo $nn;
?>
